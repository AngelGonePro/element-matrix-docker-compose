# matrix-element

Self-hosted chat like Discord, but yours: **Synapse** (Matrix homeserver) +
**Element Web**, Postgres, one published port. Closed/centralized by default
(no federation), accounts only by you or by single-use registration tokens.

Works through both of your paths at the same time:

| Path | Hostname | Route |
|---|---|---|
| Cloudflare Tunnel | `chat.cosmoscraft.net` | cloudflared → home proxy `:80` → stack |
| FRP (no Cloudflare) | `chat.cosmoscraft.net` | Linode `:443` → frps → frpc → home proxy `:8080` → stack |
| LAN direct | either name via local DNS | home proxy `:443` → stack |

Element always talks to the hostname it was opened on, so each path works on its own.

## What you get

Messages, replies, threads, reactions, edits, spaces (= Discord servers) with
rooms (= channels), DMs, end-to-end encryption, file/image/video/voice-message
uploads with thumbnails, link previews/embeds (incl. YouTube/X oEmbed), polls,
user search across the server, presence, read receipts, typing, room
directory, moderation/power levels, labs features.

**Voice/video calls** (1:1 and group, screen sharing) through Element Call
and your own LiveKit server, plus Discord-style **video rooms** (voice/video
channels). Call audio/video never touches a third-party service.

**Admin web UI** (Ketesa, formerly Synapse Admin) on its own hostname:
users (create, reset password, deactivate, make admin), rooms, media,
reports, registration tokens.

## Files

```
matrix-element/
├── docker-compose.yml
├── .env                             ← every setting lives here
├── deploy-update.sh                 ← the install/update command runs this
├── synapse/
│   ├── entrypoint.sh                ← renders config, makes signing key, drops to uid 991
│   ├── render-config.py             ← .env → homeserver.yaml on every start
│   ├── media-cleanup.py             ← deletes uploads older than MEDIA_DELETE_AFTER_DAYS
│   └── extra.d/                     ← optional *.yaml overrides for Synapse
├── element/
│   ├── default.conf.template        ← web front: Element, Matrix API, calls, admin UI port
│   ├── element-security-headers.conf
│   └── 19-render-element-config.sh  ← .env → Element config.json on every start
```

## Install / update (same command for both)

```bash
curl -fsSL -o /tmp/matrix-element.zip https://github.com/AngelGonePro/element-matrix-docker-compose/raw/refs/heads/main/matrix-element.zip && python3 -c "import zipfile;open('/tmp/matrix-element-deploy.sh','wb').write(zipfile.ZipFile('/tmp/matrix-element.zip').read('matrix-element/deploy-update.sh'))" && bash /tmp/matrix-element-deploy.sh /tmp/matrix-element.zip ~/matrix-element
```

Needs only `curl`, `python3` and Docker with the compose plugin (no `unzip`).

The first run puts the project in `~/matrix-element`, generates the database
password, and stops. Check `.env` (**`MATRIX_SERVER_NAME` becomes
`@you:<that>` forever**), then run the same command again to start it. It
waits until everything answers and, on a new server, prints the command to
create your admin account:
```bash
cd ~/matrix-element && docker compose exec synapse register_new_matrix_user -c /data/homeserver.yaml http://localhost:8008 -a
```
(`--no-admin` instead of `-a` for normal users.)

Every later run upgrades in place:

- `.env`, `data/` and `backups/` are never overwritten.
- Files you edited are left alone and reported.
- New `.env` keys are added with their defaults at the bottom.
- Image pins (`SYNAPSE_IMAGE`, `ELEMENT_IMAGE`, `POSTGRES_IMAGE`) move to the
  release's new versions only if you left them at the previous release's
  value; a version you set yourself stays. A Postgres **major** version change
  is never applied automatically (it needs a dump/restore).
- Before an image changes, the new images are pulled first (nothing is changed
  if that fails) and the database is dumped to `backups/`, since Synapse's
  database upgrades are one-way.
- Nothing is deleted automatically; files a release removed are only reported.

## Reverse proxy

The four site configs ship separately (not in the zip):

| File | Paste into | Backend |
|---|---|---|
| `proxy-nginx-chat.cosmoscraft.net.conf` | home nginx-ui | `10.0.0.152:8095` (`HTTP_PORT`) |
| `proxy-nginx-chatadmin.cosmoscraft.net.conf` | home nginx-ui | `10.0.0.152:8096` (`ADMIN_HTTP_PORT`) |
| `linode-chat.cosmoscraft.net.conf` | Linode nginx-ui | shared tunnel `127.0.0.1:8444` |
| `linode-chatadmin.cosmoscraft.net.conf` | Linode nginx-ui | shared tunnel `127.0.0.1:8444` |

Change `10.0.0.152` if the stack lives on another VM, and `8444` if your
`TUNNEL_LOCAL_PORT` differs. No new frpc proxy is needed for either site.

**DNS:** each hostname points one way — a Cloudflare Tunnel public hostname
(`http://10.0.0.100:80`, the home proxy's port 80) **or** an A record to the
Linode (DNS-only, grey cloud).

## Calls: forward the two media ports

Call sign-in and signalling go through `chat.cosmoscraft.net` like everything
else. The audio/video itself is real-time traffic that goes straight to
`CALL_PUBLIC_IP` (the Linode) on two ports, which FRP must forward to this VM
**with the same port numbers** (LiveKit tells clients exactly those numbers):

| Port | Protocol | Tunnel |
|---|---|---|
| `CALL_UDP_PORT` (7882) | UDP | your KCP voip tunnel (`frpc-voip`), public port = remotePort |
| `CALL_TCP_PORT` (7881) | TCP | main `frpc`, exposed by ratelimit-gen from the name suffix |

`frpc-voip.toml` (home):
```toml
[[proxies]]
name = "matrixcall-udp-7882"
type = "udp"
localIP = "10.0.0.152"
localPort = 7882
remotePort = 7882
```

`frpc.toml` (home) — name ends in the public port, remotePort is internal-only:
```toml
[[proxies]]
name = "matrixcall-tcp-7881"
type = "tcp"
localIP = "10.0.0.152"
localPort = 7881
remotePort = 40010
```

Restart both frpc containers, and allow UDP 7882 + TCP 7881 inbound on the
Linode if anything firewalls it. Cloudflare Tunnel can't carry call media —
calls work for everyone either way, because media always goes via the Linode.

All calls use Element Call (`element_call.use_exclusively`), so there's no
separate TURN server to run. Clients that can't use UDP fall back to TCP 7881.

## Admin web UI

`https://chatadmin.cosmoscraft.net` → log in with an admin account (e.g.
`@angel`). The Synapse admin API is reachable **only** through this site —
it returns 404 on `chat.cosmoscraft.net`.

To lock it to your own IPs, set `ADMIN_ALLOW_IPS` in `.env` (IPs or CIDRs,
space or comma separated) and run the install/update command again; anyone
else gets 403. The check uses the real visitor IP on every path (Cloudflare
Tunnel, FRP, LAN), and a forged `X-Forwarded-For` doesn't get around it.

## Changing things

Edit `.env`, then run the install/update command again (or `docker compose up -d`). Both Synapse's config and Element's
config are regenerated from `.env` on every start.

- **Upload limit:** `MAX_UPLOAD_SIZE` (e.g. `100M`, `2G`). This is the only
  place it's set — the proxy configs deliberately don't cap it. Cloudflare
  itself caps uploads at 100 MB on Free/Pro plans, so bigger files only work
  via `chat.cosmoscraft.net` (FRP).
- **Sign-ups:** `ENABLE_REGISTRATION=true` shows "Create account" in Element,
  but a token is always required. Make a single-use token:
  ```bash
  # your access token: Element → Settings → Help & About → Access Token
  docker compose exec synapse curl -s -X POST \
    -H "Authorization: Bearer <ACCESS_TOKEN>" \
    -d '{"uses_allowed": 1}' \
    http://localhost:8008/_synapse/admin/v1/registration_tokens/new
  ```
  Or click **Registration tokens → Create** in the admin UI.
  Open registration without a token is refused at startup on purpose.
- **Federation:** `ENABLE_FEDERATION=true` joins the wider Matrix network.
  With calls on, `/.well-known/matrix/server` is served either way: the call
  auth service uses it to find Synapse's OpenID check (`openid` listener
  resource — that single endpoint, not federation).
- **Anti-spam limits** (apply to every account, admins included):

  | Setting | Limits | Default | Over the limit |
  |---|---|---|---|
  | `RATE_MESSAGES_PER_SECOND` / `RATE_MESSAGES_BURST` | messages per account | 0.5/s, burst 30 | message waits, Element retries it |
  | `UPLOAD_QUOTA_PER_HOUR` / `UPLOAD_QUOTA_PER_DAY` | total upload **size** per account (blank = no quota) | 500M / 2G | upload refused ("failed to upload") |
  | `RATE_UPLOADS_PER_MINUTE` / `RATE_UPLOADS_BURST` | **number** of uploads per visitor IP (0 = off) | 30/min, burst 20 | upload refused for ~a minute |
  | `RATE_ROOMS_PER_HOUR` | new rooms per account (blank = Synapse default) | 20 | room creation refused for a while |

- **Deleting old uploads:** `MEDIA_DELETE_AFTER_DAYS=7` deletes attachments,
  images, videos and voice messages 7 days after they were uploaded, even if
  people still open them (checked every `MEDIA_CLEANUP_INTERVAL_HOURS`).
  Profile pictures, room avatars and files an admin marked **protected** (admin
  UI → Media) are always kept; link-preview images expire on their own. The
  messages stay, but the file in them shows as unavailable. Blank or 0 = keep
  files forever. The `media-cleanup` service does this through Synapse's admin
  API with its own admin account (`@mediacleanup`), created automatically.
  (`MEDIA_RETENTION_LOCAL_DAYS` is Synapse's built-in alternative: it only
  deletes files nobody has *opened* for that long.)

  Keep the message limit at 0.5 / 30 or higher if you use calls: Element Call
  sends encryption keys in bursts. Synapse lets you exempt one account from
  its rate limits via the admin API (`/_synapse/admin/v1/users/<user>/override_ratelimit`).
- **Calls:** `ENABLE_CALLS=false` turns them off; `ELEMENT_VIDEO_ROOMS=false`
  hides video rooms.
- Anything else Synapse supports: drop a `.yaml` into `synapse/extra.d/`.

## Admin API from the command line

The admin UI covers most of this, but from the host:
```bash
docker compose exec synapse curl -s -H "Authorization: Bearer <ACCESS_TOKEN>" \
  http://localhost:8008/_synapse/admin/v2/users?limit=50
```

## Notes

- Link previews in **encrypted** rooms are off by default in Element (the
  server would have to see the URL); users can enable them per room.
- Synapse's previewer refuses LAN/private/loopback addresses, so a message
  link can't be used to probe your network.
- Data lives in `DATA_DIR` (`./data`): `postgres/` and `synapse/` (media,
  signing key, generated secrets). Back up both.
- To start calls in a room, members need permission to send call events.
  Rooms and DMs created in Element set this for everyone; in an old or
  imported room, an admin can allow it under Room settings → Roles &
  Permissions → "Start Element Call calls" and "Join Element Call calls".
