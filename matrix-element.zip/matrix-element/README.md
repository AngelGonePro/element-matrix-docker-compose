# matrix-element

Self-hosted chat like Discord, but yours: **Synapse** (Matrix homeserver) +
**Element Web**, Postgres, one published port. Closed/centralized by default
(no federation), accounts only by you or by single-use registration tokens.

Works through both of your paths at the same time:

| Path | Hostname | Route |
|---|---|---|
| Cloudflare Tunnel | `chatcf.cosmoscraft.net` | cloudflared → home proxy `:80` → stack |
| FRP (no Cloudflare) | `chat.cosmoscraft.net` | Linode `:443` → frps → frpc → home proxy `:8080` → stack |
| LAN direct | either name via local DNS | home proxy `:443` → stack |

Element always talks to the hostname it was opened on, so each path works on its own.

## What you get

Messages, replies, threads, reactions, edits, spaces (= Discord servers) with
rooms (= channels), DMs, end-to-end encryption, file/image/video/voice-message
uploads with thumbnails, link previews/embeds (incl. YouTube/X oEmbed), polls,
user search across the server, presence, read receipts, typing, room
directory, moderation/power levels, labs features.

Not included: self-hosted voice/video infrastructure (TURN / LiveKit). 1:1
calls work when both sides can connect directly; group calls use
`ELEMENT_JITSI_DOMAIN` (Element's public Jitsi if blank).

## Files

```
matrix-element/
├── docker-compose.yml
├── .env                             ← every setting lives here
├── deploy-update.sh                 ← the install/update command runs this
├── synapse/
│   ├── entrypoint.sh                ← renders config, makes signing key, drops to uid 991
│   ├── render-config.py             ← .env → homeserver.yaml on every start
│   └── extra.d/                     ← optional *.yaml overrides for Synapse
├── element/
│   ├── default.conf.template        ← web front: Element + /_matrix proxy + .well-known
│   ├── element-security-headers.conf
│   └── 19-render-element-config.sh  ← .env → Element config.json on every start
```

## Install / update (same command for both)

```bash
curl -fsSL -o /tmp/matrix-element.zip https://github.com/AngelGonePro/matrix-element/raw/refs/heads/main/matrix-element.zip && python3 -c "import zipfile;open('/tmp/matrix-element-deploy.sh','wb').write(zipfile.ZipFile('/tmp/matrix-element.zip').read('matrix-element/deploy-update.sh'))" && bash /tmp/matrix-element-deploy.sh /tmp/matrix-element.zip ~/matrix-element
```

Needs only `curl`, `python3` and Docker with the compose plugin (no `unzip`).

The first run puts the project in `~/matrix-element`, generates the database
password, and stops. Check `.env` (**`MATRIX_SERVER_NAME` becomes
`@you:<that>` forever**), then run the same command again to start it. It
waits until everything answers and, on a new server, prints the command to
create your admin account:
```bash
cd ~/matrix-element && docker compose exec synapse register_new_matrix_user -c /data/homeserver.yaml http://localhost:8008 -a
```
(`--no-admin` instead of `-a` for normal users.)

Every later run upgrades in place:

- `.env`, `data/` and `backups/` are never overwritten.
- Files you edited are left alone and reported.
- New `.env` keys are added with their defaults at the bottom.
- Image pins (`SYNAPSE_IMAGE`, `ELEMENT_IMAGE`, `POSTGRES_IMAGE`) move to the
  release's new versions only if you left them at the previous release's
  value; a version you set yourself stays. A Postgres **major** version change
  is never applied automatically (it needs a dump/restore).
- Before an image changes, the new images are pulled first (nothing is changed
  if that fails) and the database is dumped to `backups/`, since Synapse's
  database upgrades are one-way.
- Nothing is deleted automatically; files a release removed are only reported.

## Reverse proxy

The two site configs ship separately (not in the zip):

1. **Home nginx-ui:** paste `proxy-nginx-chat.cosmoscraft.net.conf`.
   Change `10.0.0.50:8095` if the stack lives on another VM/port.
2. **Linode nginx-ui:** paste `linode-chat.cosmoscraft.net.conf`.
   Change `8444` if your `TUNNEL_LOCAL_PORT` differs. No new frpc proxy is needed.
3. **DNS:** `chat` → A record to the Linode, DNS-only (grey cloud).
   **Cloudflare Tunnel:** public hostname `chatcf.cosmoscraft.net` → `http://<home proxy IP>:80`.

## Changing things

Edit `.env`, then run the install/update command again (or `docker compose up -d`). Both Synapse's config and Element's
config are regenerated from `.env` on every start.

- **Upload limit:** `MAX_UPLOAD_SIZE` (e.g. `100M`, `2G`). This is the only
  place it's set — the proxy configs deliberately don't cap it. Cloudflare
  itself caps uploads at 100 MB on Free/Pro plans, so bigger files only work
  via `chat.cosmoscraft.net` (FRP).
- **Sign-ups:** `ENABLE_REGISTRATION=true` shows "Create account" in Element,
  but a token is always required. Make a single-use token:
  ```bash
  # your access token: Element → Settings → Help & About → Access Token
  docker compose exec synapse curl -s -X POST \
    -H "Authorization: Bearer <ACCESS_TOKEN>" \
    -d '{"uses_allowed": 1}' \
    http://localhost:8008/_synapse/admin/v1/registration_tokens/new
  ```
  Open registration without a token is refused at startup on purpose.
- **Federation:** `ENABLE_FEDERATION=true` joins the wider Matrix network
  (serves `/.well-known/matrix/server` delegating to `:443`).
- Anything else Synapse supports: drop a `.yaml` into `synapse/extra.d/`.

## Admin API

Not exposed through the web front (returns 404 publicly). Use it from the host:
```bash
docker compose exec synapse curl -s -H "Authorization: Bearer <ACCESS_TOKEN>" \
  http://localhost:8008/_synapse/admin/v2/users?limit=50
```

## Notes

- Link previews in **encrypted** rooms are off by default in Element (the
  server would have to see the URL); users can enable them per room.
- Synapse's previewer refuses LAN/private/loopback addresses, so a message
  link can't be used to probe your network.
- Data lives in `DATA_DIR` (`./data`): `postgres/` and `synapse/` (media,
  signing key, generated secrets). Back up both.
