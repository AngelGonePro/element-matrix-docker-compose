#!/bin/sh
# Runs inside the Element Web container (nginx entrypoint hook, after the
# image's own 18-load-element-modules.sh and before 20-envsubst-on-templates).
# Builds Element's config.json from .env into /tmp/element-web-config,
# which is the directory nginx serves /config*.json from.
#
# base_url is written as a placeholder; nginx swaps in the hostname the
# visitor actually used (sub_filter in default.conf.template), so Element
# talks to the same hostname it was loaded from — Cloudflare-tunnel users
# stay on the Cloudflare hostname, FRP users stay on the FRP hostname.
set -eu

OUT=/tmp/element-web-config
mkdir -p "$OUT"
rm -f "$OUT"/config*.json "$OUT"/wellknown-server.json

is_true() {
    case "$(printf '%s' "${1:-}" | tr 'A-Z' 'a-z')" in
        1|true|yes|on) return 0 ;;
        *) return 1 ;;
    esac
}
jbool() { if is_true "${1:-}"; then echo true; else echo false; fi; }

: "${MATRIX_SERVER_NAME:?MATRIX_SERVER_NAME must be set in .env}"

FEDERATE=$(jbool "${ENABLE_FEDERATION:-false}")
REGISTRATION=$(jbool "${ENABLE_REGISTRATION:-false}")
INTEGRATIONS=$(jbool "${ELEMENT_INTEGRATIONS:-false}")
LABS=$(jbool "${ELEMENT_SHOW_LABS:-true}")

jq -n \
    --arg server_name "$MATRIX_SERVER_NAME" \
    --arg brand "${ELEMENT_BRAND:-Element}" \
    --arg theme "${ELEMENT_DEFAULT_THEME:-dark}" \
    --arg country "${ELEMENT_DEFAULT_COUNTRY:-US}" \
    --arg jitsi "${ELEMENT_JITSI_DOMAIN:-}" \
    --arg map_style "${ELEMENT_MAP_STYLE_URL:-}" \
    --argjson federate "$FEDERATE" \
    --argjson registration "$REGISTRATION" \
    --argjson integrations "$INTEGRATIONS" \
    --argjson labs "$LABS" \
'{
    default_server_config: {
        "m.homeserver": { base_url: "__ELEMENT_BASE_URL__", server_name: $server_name }
    },
    disable_custom_urls: true,
    disable_guests: true,
    disable_3pid_login: true,
    disable_login_language_selector: false,
    force_verification: true,
    brand: $brand,
    default_theme: $theme,
    default_country_code: $country,
    default_federate: $federate,
    permalink_prefix: "__ELEMENT_BASE_URL__",
    show_labs_settings: $labs,
    room_directory: { servers: [ $server_name ] },
    mobile_guide_toast: false,
    setting_defaults: {
        breadcrumbs: true,
        "UIFeature.registration": $registration,
        "UIFeature.passwordReset": false,
        "UIFeature.identityServer": false,
        "UIFeature.thirdPartyId": false,
        "UIFeature.feedback": false,
        "UIFeature.widgets": true,
        "UIFeature.voip": true
    },
    features: {}
}
+ (if $integrations then {
        integrations_ui_url: "https://scalar.vector.im/",
        integrations_rest_url: "https://scalar.vector.im/api",
        integrations_widgets_urls: [
            "https://scalar.vector.im/_matrix/integrations/v1",
            "https://scalar.vector.im/api"
        ]
    } else {
        integrations_ui_url: null,
        integrations_rest_url: null,
        integrations_widgets_urls: null
    } end)
+ (if $jitsi != "" then { jitsi: { preferred_domain: $jitsi } } else {} end)
+ (if $map_style != "" then { map_style_url: $map_style } else {} end)
' > "$OUT/config.json"

# Federation delegation: other homeservers find us at <public host>:443.
if [ "$FEDERATE" = "true" ]; then
    PUBLIC_HOST=$(printf '%s' "${MATRIX_PUBLIC_BASEURL:-https://$MATRIX_SERVER_NAME/}" \
        | sed -E 's#^[a-zA-Z]+://##; s#/.*$##; s#:[0-9]+$##')
    jq -n --arg s "${PUBLIC_HOST}:443" '{"m.server": $s}' > "$OUT/wellknown-server.json"
fi

echo "19-render-element-config.sh: wrote $OUT/config.json (server_name=$MATRIX_SERVER_NAME, federation=$FEDERATE, registration=$REGISTRATION)"
