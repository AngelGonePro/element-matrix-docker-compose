#!/bin/sh
# Runs inside the Element Web container (nginx entrypoint hook, after the
# image's own 18-load-element-modules.sh and before 20-envsubst-on-templates).
# Builds Element's config.json from .env into /tmp/element-web-config,
# which is the directory nginx serves /config*.json from.
#
# base_url is written as a placeholder; nginx swaps in the hostname the
# visitor actually used (sub_filter in default.conf.template), so Element
# talks to the same hostname it was loaded from — Cloudflare-tunnel users
# stay on the Cloudflare hostname, FRP users stay on the FRP hostname.
set -eu

OUT=/tmp/element-web-config
mkdir -p "$OUT"
rm -f "$OUT"/config*.json "$OUT"/wellknown-server.json "$OUT"/admin-allow.conf "$OUT"/ratelimit-http.conf "$OUT"/upload-limit.conf

is_true() {
    case "$(printf '%s' "${1:-}" | tr 'A-Z' 'a-z')" in
        1|true|yes|on) return 0 ;;
        *) return 1 ;;
    esac
}
jbool() { if is_true "${1:-}"; then echo true; else echo false; fi; }

: "${MATRIX_SERVER_NAME:?MATRIX_SERVER_NAME must be set in .env}"

FEDERATE=$(jbool "${ENABLE_FEDERATION:-false}")
REGISTRATION=$(jbool "${ENABLE_REGISTRATION:-false}")
INTEGRATIONS=$(jbool "${ELEMENT_INTEGRATIONS:-false}")
LABS=$(jbool "${ELEMENT_SHOW_LABS:-true}")
CALLS=$(jbool "${ENABLE_CALLS:-true}")
VIDEO_ROOMS=$(jbool "${ELEMENT_VIDEO_ROOMS:-true}")

jq -n \
    --arg server_name "$MATRIX_SERVER_NAME" \
    --arg brand "${ELEMENT_BRAND:-Element}" \
    --arg theme "${ELEMENT_DEFAULT_THEME:-dark}" \
    --arg country "${ELEMENT_DEFAULT_COUNTRY:-US}" \
    --arg jitsi "${ELEMENT_JITSI_DOMAIN:-}" \
    --arg map_style "${ELEMENT_MAP_STYLE_URL:-}" \
    --argjson federate "$FEDERATE" \
    --argjson registration "$REGISTRATION" \
    --argjson integrations "$INTEGRATIONS" \
    --argjson labs "$LABS" \
    --argjson calls "$CALLS" \
    --argjson video_rooms "$VIDEO_ROOMS" \
'{
    default_server_config: {
        "m.homeserver": { base_url: "__ELEMENT_BASE_URL__", server_name: $server_name }
    },
    disable_custom_urls: true,
    disable_guests: true,
    disable_3pid_login: true,
    disable_login_language_selector: false,
    force_verification: true,
    brand: $brand,
    default_theme: $theme,
    default_country_code: $country,
    default_federate: $federate,
    permalink_prefix: "__ELEMENT_BASE_URL__",
    show_labs_settings: $labs,
    room_directory: { servers: [ $server_name ] },
    mobile_guide_toast: false,
    setting_defaults: {
        breadcrumbs: true,
        "UIFeature.registration": $registration,
        "UIFeature.passwordReset": false,
        "UIFeature.identityServer": false,
        "UIFeature.thirdPartyId": false,
        "UIFeature.feedback": false,
        "UIFeature.widgets": true,
        "UIFeature.voip": $calls
    },
    # All calls (DMs too) go through Element Call + your LiveKit server,
    # so there is one media path and no separate TURN server to run.
    element_call: (if $calls then { use_exclusively: true, brand: "Element Call" } else { disable: true } end),
    # Video rooms = Discord-style voice/video channels.
    features: (if $calls and $video_rooms then {
        feature_video_rooms: true,
        feature_element_call_video_rooms: true
    } else {} end)
}
+ (if $integrations then {
        integrations_ui_url: "https://scalar.vector.im/",
        integrations_rest_url: "https://scalar.vector.im/api",
        integrations_widgets_urls: [
            "https://scalar.vector.im/_matrix/integrations/v1",
            "https://scalar.vector.im/api"
        ]
    } else {
        integrations_ui_url: null,
        integrations_rest_url: null,
        integrations_widgets_urls: null
    } end)
+ (if $jitsi != "" then { jitsi: { preferred_domain: $jitsi } } else {} end)
+ (if $map_style != "" then { map_style_url: $map_style } else {} end)
' > "$OUT/config.json"

# Admin UI allowlist (ADMIN_ALLOW_IPS: IPs/CIDRs separated by spaces or commas).
: > "$OUT/admin-allow.conf"
for ip in $(printf '%s' "${ADMIN_ALLOW_IPS:-}" | tr ',' ' '); do
    case "$ip" in
        *[!0-9A-Fa-f.:/]*|"") echo "19-render-element-config.sh: ignoring invalid ADMIN_ALLOW_IPS entry '$ip'" >&2; continue ;;
    esac
    printf 'allow %s;\n' "$ip" >> "$OUT/admin-allow.conf"
done
if [ -s "$OUT/admin-allow.conf" ]; then
    echo "deny all;" >> "$OUT/admin-allow.conf"
    ADMIN_ACCESS="only: $(grep -c '^allow' "$OUT/admin-allow.conf") allowed range(s)"
else
    ADMIN_ACCESS="everyone (login required)"
fi

# Upload request limit per visitor IP (RATE_UPLOADS_PER_MINUTE, 0 = off).
# Synapse's own UPLOAD_QUOTA_* limits the total SIZE per user; this limits
# how MANY uploads one visitor can fire off.
UP_RATE="${RATE_UPLOADS_PER_MINUTE:-30}"; UP_BURST="${RATE_UPLOADS_BURST:-20}"
case "$UP_RATE$UP_BURST" in *[!0-9]*|"") echo "19-render-element-config.sh: RATE_UPLOADS_PER_MINUTE / RATE_UPLOADS_BURST must be whole numbers" >&2; exit 1 ;; esac
: > "$OUT/ratelimit-http.conf"; : > "$OUT/upload-limit.conf"
if [ "$UP_RATE" -gt 0 ]; then
    printf 'limit_req_zone $binary_remote_addr zone=matrix_uploads:10m rate=%sr/m;\n' "$UP_RATE" > "$OUT/ratelimit-http.conf"
    printf 'limit_req zone=matrix_uploads burst=%s nodelay;\n' "$UP_BURST" > "$OUT/upload-limit.conf"
    UPLOADS="$UP_RATE/min per IP (burst $UP_BURST)"
else
    UPLOADS="off"
fi

# Delegation to <public host>:443. Needed for federation, and for calls: the
# call auth service finds Synapse's OpenID check through this record.
if [ "$FEDERATE" = "true" ] || [ "$CALLS" = "true" ]; then
    PUBLIC_HOST=$(printf '%s' "${MATRIX_PUBLIC_BASEURL:-https://$MATRIX_SERVER_NAME/}" \
        | sed -E 's#^[a-zA-Z]+://##; s#/.*$##; s#:[0-9]+$##')
    jq -n --arg s "${PUBLIC_HOST}:443" '{"m.server": $s}' > "$OUT/wellknown-server.json"
fi

echo "19-render-element-config.sh: wrote $OUT/config.json (server_name=$MATRIX_SERVER_NAME, federation=$FEDERATE, registration=$REGISTRATION, calls=$CALLS, uploads: $UPLOADS, admin UI: $ADMIN_ACCESS)"
