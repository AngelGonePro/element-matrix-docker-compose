#!/usr/bin/env bash
# ==============================================================================
# deploy-update.sh - pull the latest matrix-element release zip from GitHub and
# apply it over this install WITHOUT touching your real .env values.
#
#   ./deploy-update.sh
#
# What it does:
#   1. Downloads the release zip (DEPLOY_ZIP_URL in .env) into a temp folder.
#   2. Works out your new .env: your values are kept as-is, settings that are
#      new in the release are appended. Image pins (*_IMAGE) follow the
#      release only if yours still equal the previous release's default.
#   3. If any image changes: pulls the new images FIRST (nothing on disk is
#      touched if that fails) and saves a Postgres dump to ./backups/
#      (Synapse database upgrades are one-way).
#   4. Copies every file over this install EXCEPT .env, writes the new .env
#      (old one kept as .env.bak.<timestamp>), then: docker compose up -d
#
# Never touched: .env values you set, ./data (database, media, keys),
# synapse/extra.d/*.yaml overrides you added.
#
# One-off different source:  DEPLOY_ZIP_URL=https://.../matrix-element.zip ./deploy-update.sh
# ==============================================================================
set -euo pipefail

HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$HERE"

for tool in curl unzip docker; do
  command -v "$tool" >/dev/null 2>&1 || { echo "ERROR: '$tool' is required but not installed." >&2; exit 1; }
done
[ -f .env ] || { echo "ERROR: no .env in $HERE - run this from your existing install folder." >&2; exit 1; }

# value of KEY in an env file ("" if absent); last occurrence wins, like compose
env_get() { grep -E "^$1=" "$2" 2>/dev/null | tail -n1 | cut -d= -f2- || true; }

ZIP_URL="${DEPLOY_ZIP_URL:-$(env_get DEPLOY_ZIP_URL .env)}"
ZIP_URL="${ZIP_URL:-https://raw.githubusercontent.com/AngelGonePro/matrix-element/refs/heads/main/matrix-element.zip}"

TMP="$(mktemp -d)"
trap 'rm -rf "$TMP"' EXIT

echo "==> Downloading $ZIP_URL"
curl -fL --retry 3 -o "$TMP/release.zip" "$ZIP_URL"
unzip -q "$TMP/release.zip" -d "$TMP/extract"

SRC="$TMP/extract/matrix-element"
[ -f "$SRC/docker-compose.yml" ] && [ -f "$SRC/.env.example" ] \
  || { echo "ERROR: zip doesn't contain matrix-element/docker-compose.yml and .env.example" >&2; exit 1; }

STAMP="$(date +%Y%m%d-%H%M%S)"
OLD_DEFAULTS=".env.example"          # defaults of the release you're on now
NEW_DEFAULTS="$SRC/.env.example"     # defaults of the release being installed
cp -p .env "$TMP/merged.env"

# --- image pins: follow the release only if you never changed them ----------
images_changed=0
db_major_blocked=0
while IFS= read -r key; do
  mine="$(env_get "$key" .env)"
  old="$(env_get "$key" "$OLD_DEFAULTS")"
  new="$(env_get "$key" "$NEW_DEFAULTS")"
  [ -n "$new" ] || continue
  [ -n "$mine" ] || continue                 # brand-new key: appended below
  [ "$mine" != "$new" ] || continue          # already on it
  if [ "$key" = "POSTGRES_IMAGE" ]; then
    # A Postgres MAJOR change can't start on the old data dir - never do it automatically.
    major() { printf '%s' "${1##*:}" | grep -oE '^[0-9]+' || true; }
    if [ "$(major "$mine")" != "$(major "$new")" ]; then
      echo "    ! $key: release uses $new (major version change) - NOT applied automatically."
      echo "      Your data needs a pg_dump/restore for that; staying on $mine."
      db_major_blocked=1
      continue
    fi
  fi
  if [ -n "$old" ] && [ "$mine" = "$old" ]; then
    sed -i "s|^${key}=.*|${key}=${new}|" "$TMP/merged.env"
    echo "    ~ $key: $mine -> $new"
    images_changed=1
  else
    echo "    = $key: you pinned $mine yourself - leaving it (release default is $new)"
  fi
done < <(grep -oE '^[A-Z0-9_]+_IMAGE=' "$NEW_DEFAULTS" | tr -d '=')

# --- append settings that are new in the release (by KEY, never by value) --
added=0
while IFS= read -r line; do
  case "$line" in
    [A-Za-z_]*=*) key="${line%%=*}" ;;
    *) continue ;;
  esac
  if ! grep -q "^${key}=" "$TMP/merged.env"; then
    [ "$added" -eq 0 ] && printf '\n# ---- added by deploy-update.sh %s ----\n' "$STAMP" >> "$TMP/merged.env"
    printf '%s\n' "$line" >> "$TMP/merged.env"
    echo "    + new setting: $key"
    added=$((added + 1))
  fi
done < "$NEW_DEFAULTS"
[ "$added" -eq 0 ] && echo "==> No new .env settings"

# --- validate the new compose file against the new .env before touching anything
docker compose --project-directory "$HERE" -f "$SRC/docker-compose.yml" --env-file "$TMP/merged.env" config -q \
  || { echo "ERROR: the new release doesn't validate with your .env - nothing was changed." >&2; exit 1; }

if [ "$images_changed" -eq 1 ]; then
  echo "==> Pulling new images (nothing is changed if this fails)"
  docker compose --project-directory "$HERE" -f "$SRC/docker-compose.yml" --env-file "$TMP/merged.env" pull \
    || { echo "ERROR: image pull failed - nothing was changed." >&2; exit 1; }

  if docker compose ps --status running --services 2>/dev/null | grep -qx postgres; then
    mkdir -p backups
    DUMP="backups/synapse-$STAMP.sql.gz"
    echo "==> Database backup before upgrading: $DUMP"
    if ! docker compose exec -T postgres sh -c 'pg_dump -U "$POSTGRES_USER" -d "$POSTGRES_DB"' | gzip > "$DUMP" \
       || [ "$(gzip -dc "$DUMP" | head -c 1 | wc -c)" -eq 0 ]; then
      rm -f "$DUMP"
      echo "ERROR: database backup failed - nothing was changed." >&2
      exit 1
    fi
  fi
fi

# --- apply -------------------------------------------------------------------
cp -p .env ".env.bak.$STAMP"
echo "==> Backed up .env to .env.bak.$STAMP"
echo "==> Copying updated files"
cp -a "$SRC/." "$HERE/"
cp "$TMP/merged.env" .env
chmod 600 .env
chmod +x deploy-update.sh synapse/entrypoint.sh synapse/render-config.py element/19-render-element-config.sh 2>/dev/null || true

echo "==> Restarting"
docker compose up -d --remove-orphans
echo "==> Done."
[ "$db_major_blocked" -eq 1 ] && echo "    (see the Postgres note above)"
exit 0
