#!/bin/sh
# Synapse container entrypoint:
#   1. render homeserver.yaml + log config from .env
#   2. generate the server signing key on first boot
#   3. fix ownership, then hand off to the image's own /start.py,
#      which drops from root to UID:GID (gosu) and runs Synapse.
set -eu

DATA="${SYNAPSE_DATA_DIR:-/data}"
EXTRA="${DATA}/extra.d"
OWNER="${UID:-991}:${GID:-991}"

mkdir -p "$EXTRA"
python3 /matrix-init/render-config.py

# Generates signing.key only if it doesn't exist yet, then exits.
python3 -m synapse.app.homeserver \
    --config-path "${DATA}/homeserver.yaml" \
    --config-path "$EXTRA" \
    --generate-keys

# Not recursive on purpose: media_store can hold a lot of files and
# everything inside it is already created by Synapse's own user.
chown "$OWNER" "$DATA" "${DATA}/media_store" \
    "${DATA}/homeserver.yaml" "${DATA}/log.config" \
    "${DATA}/secrets.yaml" "${DATA}/signing.key"

exec /start.py run \
    --config-path "${DATA}/homeserver.yaml" \
    --config-path "$EXTRA"
