# Optional Synapse overrides.
# Any *.yaml file in this folder is loaded after the generated homeserver.yaml
# and its values win. Prefer .env for anything .env already covers.
