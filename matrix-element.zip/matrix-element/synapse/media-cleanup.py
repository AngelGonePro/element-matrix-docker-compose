#!/usr/bin/env python3
"""
Deletes uploaded files (attachments, images, videos, voice messages) once
they are MEDIA_DELETE_AFTER_DAYS old — counted from when they were uploaded,
no matter how often they're viewed. Runs every MEDIA_CLEANUP_INTERVAL_HOURS.

Kept, always:
  * profile pictures and room avatars (the same rules Synapse itself uses)
  * files an admin marked "protected" (e.g. in the admin UI)
  * link-preview images (Synapse already expires those on its own)

Deletion goes through Synapse's own admin API, so the file, its thumbnails
and its database records go together. To do that it uses a dedicated admin
account (@mediacleanup), created once with Synapse's registration secret;
its password is kept in /state/media-cleanup.json.

Uses only what ships in the Synapse image (Python, psycopg2, PyYAML).
"""
import hashlib
import hmac
import json
import os
import secrets
import sys
import time
import urllib.error
import urllib.parse
import urllib.request

import psycopg2
import yaml

SYNAPSE = os.environ.get("SYNAPSE_URL", "http://synapse:8008").rstrip("/")
SERVER_NAME = os.environ["MATRIX_SERVER_NAME"]
STATE = os.environ.get("CLEANUP_STATE_FILE", "/state/media-cleanup.json")
SECRETS = os.environ.get("SYNAPSE_SECRETS_FILE", "/synapse-data/secrets.yaml")
BOT = os.environ.get("CLEANUP_BOT_LOCALPART", "mediacleanup")


def log(msg: str) -> None:
    print(f"[media-cleanup] {msg}", flush=True)


def setting(name: str, default: str, minimum: float) -> float:
    raw = os.environ.get(name, "").strip() or default
    try:
        val = float(raw)
    except ValueError:
        log(f"ERROR: {name}={raw!r} must be a number")
        sys.exit(1)
    if val < minimum:
        log(f"ERROR: {name}={raw!r} must be at least {minimum}")
        sys.exit(1)
    return val


def api(method: str, path: str, token: str | None = None, body: dict | None = None):
    data = json.dumps(body).encode() if body is not None else None
    req = urllib.request.Request(SYNAPSE + path, data=data, method=method)
    req.add_header("Content-Type", "application/json")
    if token:
        req.add_header("Authorization", f"Bearer {token}")
    try:
        with urllib.request.urlopen(req, timeout=60) as r:
            return r.status, json.loads(r.read() or b"{}")
    except urllib.error.HTTPError as e:
        try:
            return e.code, json.loads(e.read() or b"{}")
        except ValueError:
            return e.code, {}


def load_state() -> dict:
    try:
        with open(STATE) as f:
            return json.load(f)
    except FileNotFoundError:
        return {}


def save_state(state: dict) -> None:
    tmp = STATE + ".tmp"
    with open(tmp, "w") as f:
        json.dump(state, f)
    os.chmod(tmp, 0o600)
    os.replace(tmp, STATE)


def register_bot(localpart: str, password: str) -> tuple[int, dict]:
    with open(SECRETS) as f:
        shared = yaml.safe_load(f)["registration_shared_secret"]
    _, nonce = api("GET", "/_synapse/admin/v1/register")
    nonce = nonce["nonce"]
    mac = hmac.new(shared.encode(), b"\x00".join(p.encode() for p in (nonce, localpart, password, "admin")),
                   hashlib.sha1).hexdigest()
    return api("POST", "/_synapse/admin/v1/register", body={
        "nonce": nonce, "username": localpart, "password": password,
        "admin": True, "mac": mac, "displayname": "Media cleanup (automatic)",
    })


def admin_token() -> str:
    state = load_state()
    if state.get("user") and state.get("password"):
        code, r = api("POST", "/_matrix/client/v3/login", body={
            "type": "m.login.password",
            "identifier": {"type": "m.id.user", "user": state["user"]},
            "password": state["password"],
            "initial_device_display_name": "media-cleanup",
        })
        if code == 200:
            return r["access_token"]
        log(f"saved login for {state['user']} failed ({code} {r.get('errcode')}) — creating a new cleanup account")

    localpart = BOT if not state else f"{BOT}_{secrets.token_hex(3)}"
    password = secrets.token_urlsafe(32)
    code, r = register_bot(localpart, password)
    if code == 400 and r.get("errcode") == "M_USER_IN_USE":
        localpart = f"{BOT}_{secrets.token_hex(3)}"
        code, r = register_bot(localpart, password)
    if code != 200:
        raise RuntimeError(f"could not create the cleanup admin account: {code} {r}")
    save_state({"user": r["user_id"], "password": password})
    log(f"created admin account {r['user_id']} for cleanup")
    return r["access_token"]


def old_media_ids(cutoff_ms: int) -> list[str]:
    prefix = f"mxc://{SERVER_NAME}/"
    sql = """
        SELECT media_id FROM local_media_repository AS lmr
        WHERE created_ts < %(cutoff)s
          AND url_cache IS NULL
          AND quarantined_by IS NULL
          AND NOT safe_from_quarantine
          AND NOT EXISTS (SELECT 1 FROM profiles         WHERE profiles.avatar_url         = %(p)s || lmr.media_id)
          AND NOT EXISTS (SELECT 1 FROM room_memberships WHERE room_memberships.avatar_url = %(p)s || lmr.media_id)
          AND NOT EXISTS (SELECT 1 FROM user_directory   WHERE user_directory.avatar_url   = %(p)s || lmr.media_id)
          AND NOT EXISTS (SELECT 1 FROM room_stats_state WHERE room_stats_state.avatar     = %(p)s || lmr.media_id)
        ORDER BY created_ts
    """
    conn = psycopg2.connect(
        host=os.environ.get("POSTGRES_HOST", "postgres"), port=int(os.environ.get("POSTGRES_PORT", "5432")),
        dbname=os.environ["POSTGRES_DB"], user=os.environ["POSTGRES_USER"], password=os.environ["POSTGRES_PASSWORD"],
    )
    try:
        with conn.cursor() as cur:
            cur.execute(sql, {"cutoff": cutoff_ms, "p": prefix})
            return [row[0] for row in cur.fetchall()]
    finally:
        conn.close()


def run_once(days: float) -> None:
    cutoff = int((time.time() - days * 86400) * 1000)
    ids = old_media_ids(cutoff)
    if not ids:
        log(f"nothing uploaded more than {days:g} day(s) ago to delete")
        return
    token = admin_token()
    deleted = failed = 0
    for mid in ids:
        code, r = api("DELETE", f"/_synapse/admin/v1/media/{urllib.parse.quote(SERVER_NAME)}/{urllib.parse.quote(mid)}", token)
        if code == 200 and r.get("total", 0) >= 1:
            deleted += 1
        else:
            failed += 1
            log(f"could not delete {mid}: {code} {r.get('errcode', '')} {r.get('error', '')}".rstrip())
    log(f"deleted {deleted} file(s) uploaded more than {days:g} day(s) ago" + (f", {failed} failed" if failed else ""))
    api("POST", "/_matrix/client/v3/logout", token)


def main() -> None:
    days = setting("MEDIA_DELETE_AFTER_DAYS", "0", 0)
    hours = setting("MEDIA_CLEANUP_INTERVAL_HOURS", "6", 0.1)
    if days <= 0:
        log("MEDIA_DELETE_AFTER_DAYS is blank or 0 — files are kept; nothing to do")
        while True:          # stay up quietly so the stack looks healthy
            time.sleep(86400)
    once = "--once" in sys.argv
    log(f"deleting uploads older than {days:g} day(s), checking every {hours:g} hour(s)")
    while True:
        try:
            run_once(days)
        except Exception as e:  # keep going; try again next round
            log(f"ERROR: {e}")
            if once:
                sys.exit(1)
        if once:
            return
        time.sleep(hours * 3600)


if __name__ == "__main__":
    main()
