#!/usr/bin/env python3
"""
Renders Synapse's homeserver.yaml + log config from environment variables
(.env -> docker-compose -> this container) on EVERY start, so .env is the
single source of truth. Uses the Python + PyYAML that ship inside the
official Synapse image — no extra dependencies.

Secrets left blank in .env are generated once and kept in
/data/secrets.yaml so they survive restarts and updates.

For anything .env doesn't cover, drop extra *.yaml files into
synapse/extra.d/ — Synapse loads them after this file and they win.
"""
import os
import re
import secrets
import sys
from urllib.parse import urlparse

import yaml

DATA = os.environ.get("SYNAPSE_DATA_DIR", "/data")
CONFIG_PATH = os.path.join(DATA, "homeserver.yaml")
LOG_CONFIG_PATH = os.path.join(DATA, "log.config")
SECRETS_PATH = os.path.join(DATA, "secrets.yaml")


def fail(msg: str) -> None:
    print(f"[render-config] ERROR: {msg}", file=sys.stderr)
    sys.exit(1)


def env(name: str, default: str = "") -> str:
    return os.environ.get(name, default).strip()


def env_bool(name: str, default: bool) -> bool:
    raw = env(name)
    if raw == "":
        return default
    low = raw.lower()
    if low in ("1", "true", "yes", "on"):
        return True
    if low in ("0", "false", "no", "off"):
        return False
    fail(f"{name}={raw!r} is not a boolean (use true/false)")
    return default  # unreachable


SIZE_RE = re.compile(r"^[0-9]+[KMGT]?$")


def env_size(name: str, default: str) -> str:
    raw = env(name, default).upper()
    if not SIZE_RE.match(raw):
        fail(f"{name}={raw!r} must look like 100M, 2G, 512K or a plain byte count")
    return raw


def env_days(name: str) -> str | None:
    raw = env(name)
    if raw == "":
        return None
    if not raw.isdigit() or int(raw) <= 0:
        fail(f"{name}={raw!r} must be a positive whole number of days, or blank")
    return f"{int(raw)}d"


# ---------------------------------------------------------------- secrets
def load_secrets() -> dict:
    stored = {}
    if os.path.exists(SECRETS_PATH):
        with open(SECRETS_PATH) as f:
            stored = yaml.safe_load(f) or {}
    changed = False
    out = {}
    for key, env_name in (
        ("registration_shared_secret", "SYNAPSE_REGISTRATION_SHARED_SECRET"),
        ("macaroon_secret_key", "SYNAPSE_MACAROON_SECRET_KEY"),
        ("form_secret", "SYNAPSE_FORM_SECRET"),
    ):
        val = env(env_name)
        if not val:
            val = stored.get(key) or secrets.token_urlsafe(48)
        if stored.get(key) != val:
            changed = True
        out[key] = val
    if changed:
        with open(SECRETS_PATH, "w") as f:
            yaml.safe_dump(out, f)
        os.chmod(SECRETS_PATH, 0o600)
    return out


# ------------------------------------------------------------------ main
server_name = env("MATRIX_SERVER_NAME")
if not server_name:
    fail("MATRIX_SERVER_NAME must be set in .env (this becomes the :domain in every user ID and can never change)")

public_baseurl = env("MATRIX_PUBLIC_BASEURL") or f"https://{server_name}/"
if not public_baseurl.endswith("/"):
    public_baseurl += "/"
if urlparse(public_baseurl).scheme not in ("http", "https"):
    fail(f"MATRIX_PUBLIC_BASEURL={public_baseurl!r} must start with https://")

pg_password = env("POSTGRES_PASSWORD")
if not pg_password:
    fail("POSTGRES_PASSWORD must be set in .env")

federation = env_bool("ENABLE_FEDERATION", False)
registration = env_bool("ENABLE_REGISTRATION", False)
reg_token = env_bool("REGISTRATION_REQUIRES_TOKEN", True)
if registration and not reg_token:
    fail(
        "ENABLE_REGISTRATION=true with REGISTRATION_REQUIRES_TOKEN=false would let anyone on the "
        "internet create accounts with no email/captcha check. Keep REGISTRATION_REQUIRES_TOKEN=true "
        "and hand out registration tokens instead (see README)."
    )

sec = load_secrets()

calls = env_bool("ENABLE_CALLS", True)
# "openid" serves ONLY /_matrix/federation/v1/openid/userinfo — what the call
# auth service uses to check who is asking. It is not federation.
resources = ["client"] + (["federation"] if federation else ["openid"] if calls else [])

cfg = {
    "server_name": server_name,
    "public_baseurl": public_baseurl,
    "pid_file": os.path.join(DATA, "homeserver.pid"),
    "signing_key_path": os.path.join(DATA, "signing.key"),
    "log_config": LOG_CONFIG_PATH,
    "media_store_path": os.path.join(DATA, "media_store"),
    "report_stats": False,
    "enable_metrics": False,
    "serve_server_wellknown": False,  # the web container serves .well-known
    "listeners": [
        {
            "port": 8008,
            "type": "http",
            "tls": False,
            "bind_addresses": ["0.0.0.0"],
            "x_forwarded": True,
            "resources": [{"names": resources, "compress": False}],
        }
    ],
    "database": {
        "name": "psycopg2",
        "args": {
            "user": env("POSTGRES_USER", "synapse"),
            "password": pg_password,
            "dbname": env("POSTGRES_DB", "synapse"),
            "host": env("POSTGRES_HOST", "postgres"),
            "port": int(env("POSTGRES_PORT", "5432")),
            "cp_min": 5,
            "cp_max": 10,
        },
    },
    # ---- secrets
    "registration_shared_secret": sec["registration_shared_secret"],
    "macaroon_secret_key": sec["macaroon_secret_key"],
    "form_secret": sec["form_secret"],
    # ---- uploads / media
    "max_upload_size": env_size("MAX_UPLOAD_SIZE", "100M"),
    "max_image_pixels": env_size("MAX_IMAGE_PIXELS", "32M"),
    "dynamic_thumbnails": True,
    "enable_authenticated_media": True,
    # ---- link previews (embeds)
    "url_preview_enabled": env_bool("URL_PREVIEWS_ENABLED", True),
    "max_spider_size": env_size("URL_PREVIEW_MAX_SIZE", "10M"),
    "url_preview_accept_language": [env("URL_PREVIEW_LANGUAGE", "en"), "*;q=0.7"],
    # Never let the previewer fetch your LAN / Docker networks / metadata endpoints.
    "url_preview_ip_range_blacklist": [
        "127.0.0.0/8", "10.0.0.0/8", "172.16.0.0/12", "192.168.0.0/16",
        "100.64.0.0/10", "192.0.0.0/24", "169.254.0.0/16", "192.88.99.0/24",
        "198.18.0.0/15", "192.0.2.0/24", "198.51.100.0/24", "203.0.113.0/24",
        "224.0.0.0/4", "::1/128", "fe80::/10", "fc00::/7", "2001:db8::/32",
        "ff00::/8", "fec0::/10",
    ],
    # ---- accounts
    "enable_registration": registration,
    "registration_requires_token": reg_token,
    # Synapse refuses open registration without email/captcha unless this is set;
    # it's only set here when a registration token is mandatory.
    "enable_registration_without_verification": registration and reg_token,
    "allow_guest_access": False,
    "password_config": {
        "enabled": True,
        "policy": {
            "enabled": True,
            "minimum_length": int(env("PASSWORD_MIN_LENGTH", "10")),
        },
    },
    # ---- privacy
    "require_auth_for_profile_requests": True,
    "allow_public_rooms_without_auth": False,
    "allow_public_rooms_over_federation": federation,
    "presence": {"enabled": env_bool("ENABLE_PRESENCE", True)},
    "user_directory": {
        "enabled": True,
        "search_all_users": env_bool("SEARCH_ALL_USERS", True),
        "prefer_local_users": True,
    },
}

if not federation:
    # Closed, single-server mode: talk to no other homeserver at all,
    # not even matrix.org for signing keys.
    cfg["federation_domain_whitelist"] = []
    cfg["trusted_key_servers"] = []
else:
    cfg["trusted_key_servers"] = [{"server_name": "matrix.org"}]
    cfg["suppress_key_server_warning"] = True

# ---- calls (Element Call / MatrixRTC with the LiveKit SFU)
# Follows Element Call's own reference backend: lk-jwt-service runs as an
# application service, and Synapse proxies the MatrixRTC endpoints to it.
if calls:
    as_token = env("LIVEKIT_AS_TOKEN")
    hs_token = env("LIVEKIT_HS_TOKEN")
    if not as_token or not hs_token:
        fail("LIVEKIT_AS_TOKEN and LIVEKIT_HS_TOKEN must be set in .env (the install/update command generates them)")
    jwt_internal = env("LK_JWT_INTERNAL_URL", "http://lk-jwt:8080")
    registration_path = os.path.join(DATA, "lk-jwt-appservice.yaml")
    lk_registration = {
        "id": "lk-jwt-service",
        "as_token": as_token,
        "hs_token": hs_token,
        "sender_localpart": "_lk_jwt_service",
        "namespaces": {"users": [{"exclusive": False, "regex": "@.*:" + re.escape(server_name)}]},
        "url": jwt_internal,
        "io.element.msc4502.scopes": ["urn:matrix:client:io.element.msc4502:rooms:is_joined"],
        "io.element.msc4512.proxy_prefix": "rtc/livekit",
        "io.element.msc4512.proxy_url": jwt_internal,
    }
    with open(registration_path, "w") as f:
        f.write("# GENERATED from .env by synapse/render-config.py\n")
        yaml.safe_dump(lk_registration, f, sort_keys=False)
    os.chmod(registration_path, 0o600)
    cfg["app_service_config_files"] = [registration_path]
    cfg["experimental_features"] = {
        "msc4143_enabled": True,   # MatrixRTC transports endpoint
        "msc4354_enabled": True,   # sticky events
        "msc4502_enabled": True,   # membership look-ups for lk-jwt-service
        "msc4512_enabled": True,   # Synapse proxies /rtc/livekit to lk-jwt-service
    }
    cfg["max_event_delay_duration"] = "24h"   # MSC4140 delayed events
    cfg["rc_delayed_event_mgmt"] = {"per_second": 1, "burst_count": 20}
    cfg["matrix_rtc"] = {
        "transports": [{"type": "livekit", "livekit_service_url": public_baseurl + "livekit/jwt"}]
    }

# ---- anti-spam limits (all from .env)
def env_number(name: str, default: str, minimum: float, integer: bool = False):
    raw = env(name, default)
    try:
        val = int(raw) if integer else float(raw)
    except ValueError:
        fail(f"{name}={raw!r} must be a {'whole ' if integer else ''}number")
    if val < minimum:
        fail(f"{name}={raw!r} must be at least {minimum}")
    return val

msg_rate = env_number("RATE_MESSAGES_PER_SECOND", "0.5", 0.01)
msg_burst = env_number("RATE_MESSAGES_BURST", "30", 1, integer=True)
if calls and (msg_rate < 0.5 or msg_burst < 30):
    print(f"[render-config] WARNING: RATE_MESSAGES_PER_SECOND={msg_rate} / RATE_MESSAGES_BURST={msg_burst} "
          "is below what Element Call needs (0.5 / 30) — calls may stall while keys are shared.", file=sys.stderr)
cfg["rc_message"] = {"per_second": msg_rate, "burst_count": msg_burst}

rooms_per_hour = env("RATE_ROOMS_PER_HOUR")
if rooms_per_hour:
    n = env_number("RATE_ROOMS_PER_HOUR", "", 1, integer=True)
    cfg["rc_room_creation"] = {"per_second": round(n / 3600, 6), "burst_count": min(n, 10)}

quotas = []
for name, period in (("UPLOAD_QUOTA_PER_HOUR", "1h"), ("UPLOAD_QUOTA_PER_DAY", "1d")):
    if env(name):
        quotas.append({"time_period": period, "max_size": env_size(name, "")})
if quotas:
    cfg["media_upload_limits"] = quotas

retention = {}
local_days = env_days("MEDIA_RETENTION_LOCAL_DAYS")
remote_days = env_days("MEDIA_RETENTION_REMOTE_DAYS")
if local_days:
    retention["local_media_lifetime"] = local_days
if remote_days:
    retention["remote_media_lifetime"] = remote_days
if retention:
    cfg["media_retention"] = retention

log_level = env("LOG_LEVEL", "WARNING").upper()
if log_level not in ("DEBUG", "INFO", "WARNING", "ERROR", "CRITICAL"):
    fail(f"LOG_LEVEL={log_level!r} must be DEBUG, INFO, WARNING or ERROR")

log_cfg = {
    "version": 1,
    "formatters": {
        "precise": {
            "format": "%(asctime)s - %(name)s - %(lineno)d - %(levelname)s - %(request)s - %(message)s"
        }
    },
    "handlers": {
        "console": {"class": "logging.StreamHandler", "formatter": "precise"},
    },
    "loggers": {
        "synapse.storage.SQL": {"level": "WARNING"},
        # request log (method, path, client IP) — INFO shows every request
        "synapse.access": {"level": log_level},
    },
    "root": {"level": log_level, "handlers": ["console"]},
    "disable_existing_loggers": False,
}

os.makedirs(cfg["media_store_path"], exist_ok=True)
header = (
    "# GENERATED from .env by synapse/render-config.py on every start.\n"
    "# Do not edit — change .env, or add overrides in synapse/extra.d/*.yaml\n"
)
for path, data in ((CONFIG_PATH, cfg), (LOG_CONFIG_PATH, log_cfg)):
    with open(path, "w") as f:
        f.write(header)
        yaml.safe_dump(data, f, sort_keys=False)
os.chmod(CONFIG_PATH, 0o600)

print(
    f"[render-config] server_name={server_name} federation={federation} "
    f"registration={registration} max_upload_size={cfg['max_upload_size']} "
    f"url_previews={cfg['url_preview_enabled']} calls={calls} "
    f"rc_message={msg_rate}/s burst {msg_burst} upload_quota={[q['time_period']+'='+q['max_size'] for q in quotas] or 'none'}"
)
